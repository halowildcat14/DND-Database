USE NWindmalikjp38
Go
Select ProductName, UnitsInStock
	FROM Products WHERE UnitsOnOrder > 0
